/* global QUnit */
sap.ui.define([
	"z/sap/courses/utils/CSVParser"
], function (CSVParser) {
	"use strict";

	QUnit.module("CSV Parser - Valid Data", {
		beforeEach: function () {
			this.validCSV = `ID,url,role,title,sap_module,description,lastUpdated,sapHelpLink
550e8400-e29b-41d4-a716-446655440001,https://learning.sap.com/course1,Developer,ABAP Development Basics,ABAP,Learn ABAP fundamentals,20260201,https://help.sap.com/abap
550e8400-e29b-41d4-a716-446655440002,https://learning.sap.com/course2,Admin,SAP Fiori Administration,UI_UX,Fiori admin guide,20260202,https://help.sap.com/fiori`;
		}
	});

	QUnit.test("Should parse valid CSV with 2 records", function (assert) {
		const result = CSVParser.parseTrainingsCSV(this.validCSV);
		
		assert.ok(result.success, "Parsing should succeed");
		assert.strictEqual(result.data.length, 2, "Should have 2 records");
		assert.strictEqual(result.errors.length, 0, "Should have no errors");
	});

	QUnit.test("Should correctly parse UUID field", function (assert) {
		const result = CSVParser.parseTrainingsCSV(this.validCSV);
		
		assert.strictEqual(
			result.data[0].ID,
			"550e8400-e29b-41d4-a716-446655440001",
			"First record ID should match"
		);
	});

	QUnit.test("Should correctly parse title field", function (assert) {
		const result = CSVParser.parseTrainingsCSV(this.validCSV);
		
		assert.strictEqual(
			result.data[0].title,
			"ABAP Development Basics",
			"Title should be parsed correctly"
		);
	});

	QUnit.test("Should correctly parse sap_module field", function (assert) {
		const result = CSVParser.parseTrainingsCSV(this.validCSV);
		
		assert.strictEqual(
			result.data[0].sap_module,
			"ABAP",
			"SAP Module should be parsed correctly"
		);
	});

	QUnit.test("Should correctly parse role field", function (assert) {
		const result = CSVParser.parseTrainingsCSV(this.validCSV);
		
		assert.strictEqual(result.data[0].role, "Developer", "Role should be Developer");
		assert.strictEqual(result.data[1].role, "Admin", "Role should be Admin");
	});

	QUnit.test("Should parse URLs correctly", function (assert) {
		const result = CSVParser.parseTrainingsCSV(this.validCSV);
		
		assert.strictEqual(
			result.data[0].url,
			"https://learning.sap.com/course1",
			"URL should be parsed correctly"
		);
	});

	QUnit.module("CSV Parser - Invalid Data");

	QUnit.test("Should reject empty CSV", function (assert) {
		const result = CSVParser.parseTrainingsCSV("");
		
		assert.notOk(result.success, "Parsing should fail");
		assert.ok(result.errors.length > 0, "Should have errors");
	});

	QUnit.test("Should reject CSV with headers only", function (assert) {
		const csv = "ID,url,role,title,sap_module,description,lastUpdated,sapHelpLink";
		const result = CSVParser.parseTrainingsCSV(csv);
		
		assert.notOk(result.success, "Parsing should fail");
		assert.ok(result.errors.length > 0, "Should have errors");
	});

	QUnit.test("Should reject invalid UUID", function (assert) {
		const csv = `ID,url,role,title,sap_module,description,lastUpdated,sapHelpLink
INVALID-UUID,https://test.com,Developer,Test,ABAP,Desc,20260201,https://help.com`;
		
		const result = CSVParser.parseTrainingsCSV(csv);
		
		assert.notOk(result.success, "Parsing should fail");
		assert.ok(
			result.errors.some(e => e.includes("Invalid UUID")),
			"Should have UUID validation error"
		);
	});

	QUnit.test("Should reject missing required field (title)", function (assert) {
		const csv = `ID,url,role,title,sap_module,description,lastUpdated,sapHelpLink
550e8400-e29b-41d4-a716-446655440001,https://test.com,Developer,,ABAP,Desc,20260201,https://help.com`;
		
		const result = CSVParser.parseTrainingsCSV(csv);
		
		assert.notOk(result.success, "Parsing should fail");
		assert.ok(
			result.errors.some(e => e.includes("Title is required")),
			"Should have title validation error"
		);
	});

	QUnit.test("Should reject invalid role", function (assert) {
		const csv = `ID,url,role,title,sap_module,description,lastUpdated,sapHelpLink
550e8400-e29b-41d4-a716-446655440001,https://test.com,InvalidRole,Test,ABAP,Desc,20260201,https://help.com`;
		
		const result = CSVParser.parseTrainingsCSV(csv);
		
		assert.notOk(result.success, "Parsing should fail");
		assert.ok(
			result.errors.some(e => e.includes("Invalid role")),
			"Should have role validation error"
		);
	});

	QUnit.test("Should reject invalid URL", function (assert) {
		const csv = `ID,url,role,title,sap_module,description,lastUpdated,sapHelpLink
550e8400-e29b-41d4-a716-446655440001,not-a-url,Developer,Test,ABAP,Desc,20260201,https://help.com`;
		
		const result = CSVParser.parseTrainingsCSV(csv);
		
		assert.notOk(result.success, "Parsing should fail");
		assert.ok(
			result.errors.some(e => e.includes("Invalid URL")),
			"Should have URL validation error"
		);
	});

	QUnit.test("Should reject title too long", function (assert) {
		const longTitle = "A".repeat(101); // 101 characters
		const csv = `ID,url,role,title,sap_module,description,lastUpdated,sapHelpLink
550e8400-e29b-41d4-a716-446655440001,https://test.com,Developer,${longTitle},ABAP,Desc,20260201,https://help.com`;
		
		const result = CSVParser.parseTrainingsCSV(csv);
		
		assert.notOk(result.success, "Parsing should fail");
		assert.ok(
			result.errors.some(e => e.includes("Title too long")),
			"Should have length validation error"
		);
	});

	QUnit.module("CSV Parser - Special Cases");

	QUnit.test("Should handle quoted values with commas", function (assert) {
		const csv = `ID,url,role,title,sap_module,description,lastUpdated,sapHelpLink
550e8400-e29b-41d4-a716-446655440001,https://test.com,Developer,"Title with, comma",ABAP,Desc,20260201,https://help.com`;
		
		const result = CSVParser.parseTrainingsCSV(csv);
		
		assert.ok(result.success, "Parsing should succeed");
		assert.strictEqual(
			result.data[0].title,
			"Title with, comma",
			"Should handle comma in quoted field"
		);
	});

	QUnit.test("Should handle escaped quotes", function (assert) {
		const csv = `ID,url,role,title,sap_module,description,lastUpdated,sapHelpLink
550e8400-e29b-41d4-a716-446655440001,https://test.com,Developer,"Title with ""quotes""",ABAP,Desc,20260201,https://help.com`;
		
		const result = CSVParser.parseTrainingsCSV(csv);
		
		assert.ok(result.success, "Parsing should succeed");
		assert.strictEqual(
			result.data[0].title,
			'Title with "quotes"',
			"Should handle escaped quotes"
		);
	});

	QUnit.test("Should sanitize XSS attempts", function (assert) {
		const csv = `ID,url,role,title,sap_module,description,lastUpdated,sapHelpLink
550e8400-e29b-41d4-a716-446655440001,https://test.com,Developer,<script>alert('xss')</script>,ABAP,Test,20260201,https://help.com`;
		
		const result = CSVParser.parseTrainingsCSV(csv);
		
		assert.ok(result.success, "Parsing should succeed");
		assert.ok(
			!result.data[0].title.includes("<script>"),
			"Should sanitize script tags"
		);
	});

	QUnit.test("Should detect duplicate IDs", function (assert) {
		const csv = `ID,url,role,title,sap_module,description,lastUpdated,sapHelpLink
550e8400-e29b-41d4-a716-446655440001,https://test1.com,Developer,Title1,ABAP,Desc1,20260201,https://help.com
550e8400-e29b-41d4-a716-446655440001,https://test2.com,Admin,Title2,UI_UX,Desc2,20260202,https://help.com`;
		
		const result = CSVParser.parseTrainingsCSV(csv);
		
		assert.ok(result.success, "Parsing should succeed");
		assert.ok(
			result.warnings.some(w => w.includes("Duplicate IDs")),
			"Should warn about duplicate IDs"
		);
	});

	QUnit.test("Should skip empty lines", function (assert) {
		const csv = `ID,url,role,title,sap_module,description,lastUpdated,sapHelpLink

550e8400-e29b-41d4-a716-446655440001,https://test.com,Developer,Test,ABAP,Desc,20260201,https://help.com

550e8400-e29b-41d4-a716-446655440002,https://test2.com,Admin,Test2,UI_UX,Desc2,20260202,https://help.com`;
		
		const result = CSVParser.parseTrainingsCSV(csv);
		
		assert.ok(result.success, "Parsing should succeed");
		assert.strictEqual(result.data.length, 2, "Should have 2 records (empty lines skipped)");
	});

	QUnit.test("Should handle different date formats", function (assert) {
		const csv = `ID,url,role,title,sap_module,description,lastUpdated,sapHelpLink
550e8400-e29b-41d4-a716-446655440001,https://test.com,Developer,Test1,ABAP,Desc,20260201,https://help.com
550e8400-e29b-41d4-a716-446655440002,https://test.com,Admin,Test2,UI_UX,Desc,2026-02-01T00:00:00Z,https://help.com`;
		
		const result = CSVParser.parseTrainingsCSV(csv);
		
		assert.ok(result.success, "Parsing should succeed");
		assert.ok(result.data[0].lastUpdated, "Should parse YYYYMMDD format");
		assert.ok(result.data[1].lastUpdated, "Should parse ISO format");
	});

	QUnit.test("Should handle missing optional fields", function (assert) {
		const csv = `ID,url,role,title,sap_module,description,lastUpdated,sapHelpLink
550e8400-e29b-41d4-a716-446655440001,,Developer,Test,ABAP,Desc,20260201,`;
		
		const result = CSVParser.parseTrainingsCSV(csv);
		
		assert.ok(result.success, "Parsing should succeed");
		assert.strictEqual(result.data[0].url, "", "Empty URL should be allowed");
		assert.strictEqual(result.data[0].sapHelpLink, "", "Empty help link should be allowed");
	});

	QUnit.module("CSV Parser - Bulk Data");

	QUnit.test("Should handle 52 records efficiently", function (assert) {
		const done = assert.async();
		
		// Generate 52 valid records
		let csv = "ID,url,role,title,sap_module,description,lastUpdated,sapHelpLink\n";
		for (let i = 1; i <= 52; i++) {
			const id = `550e8400-e29b-41d4-a716-${String(i).padStart(12, '0')}`;
			csv += `${id},https://test${i}.com,Developer,Test${i},ABAP,Description ${i},20260201,https://help.com\n`;
		}
		
		const start = Date.now();
		const result = CSVParser.parseTrainingsCSV(csv);
		const duration = Date.now() - start;
		
		assert.ok(result.success, "Parsing should succeed");
		assert.strictEqual(result.data.length, 52, "Should parse all 52 records");
		assert.ok(duration < 1000, `Parsing should be fast (took ${duration}ms)`);
		
		done();
	});

	QUnit.module("CSV Parser - Case Insensitivity");

	QUnit.test("Should handle mixed case headers", function (assert) {
		const csv = `id,URL,Role,TITLE,sap_MODULE,Description,LastUpdated,SapHelpLink
550e8400-e29b-41d4-a716-446655440001,https://test.com,Developer,Test,ABAP,Desc,20260201,https://help.com`;
		
		const result = CSVParser.parseTrainingsCSV(csv);
		
		assert.ok(result.success, "Parsing should succeed with mixed case headers");
		assert.strictEqual(result.data.length, 1, "Should parse record");
	});
});
